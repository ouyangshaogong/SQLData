package com.atguigu.dao;

import com.atguigu.bean.Admin;

public class AdminDao extends BasicDao<Admin> {
	
	
	

}
