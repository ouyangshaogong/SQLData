package com.atguigu.dao;

import com.atguigu.bean.Boys;

public class BoysDao extends BasicDao<Boys>{

}
