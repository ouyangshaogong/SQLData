#1. 查询工资最低的员工信息: last_name, salary  
SELECT last_name,MIN(salary)
FROM employees
WHERE MIN(salary);

#2. 查询平均工资最低的部门信息 
SELECT daparment_id,MIN(salary)
FROM employees;
WHERE MIN(salary);


#3. 查询平均工资最低的部门信息和该部门的平均工资 


#4. 查询平均工资最高的 job 信息 


#5. 查询平均工资高于公司平均工资的部门有哪些?  


#6. 查询出公司中所有 manager 的详细信息. 


#7. 各个部门中 最高工资中最低的那个部门的 最低工资是多少

  
#8. 查询平均工资最高的部门的 manager 的详细信息: last_name, department_id, email, salar

















